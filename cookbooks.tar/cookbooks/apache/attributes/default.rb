default["apache"]["sites"]["fernando2"] = {"port" => 80, "domain" => "fernandolinux2.mylabserver.com" }
default["apache"]["sites"]["fernando2b"] = {"port" => 80, "domain" => "fernandolinux2b.mylabserver.com" }
