#
# Cookbook Name:: apache
# Recipe:: default
#
# Copyright 2014, YOUR_COMPANY_NAME
#
# All rights reserved - Do Not Redistribute
#
# In order to install the package resource on CentOS machine
## Resource defines the action that in this case is to install apache package
package "httpd" do
	action :install
end

#Ruby loop
node["apache"]["sites"].each do |sitename, data|
  document_root = "/content/sites/#{sitename}"

#Creates the directory if doesnt exist recursively and assign permissions
  directory document_root do
	mode "0755"
	recursive true
  end

#only ofr centOS
  template "/etc/httpd/conf.d/#{sitename}.conf" do
	source "vhost.erb"
	mode "0644"
	variables(
		:document_root => document_root,
		:port => data["port"],
		:domain => data["domain"]
	)
	notifies :restart, "service[httpd]"


  
  end

end 

service "httpd" do
	action [:enable, :start]
end

